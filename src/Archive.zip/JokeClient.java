/** 
 * 
 1. Abdulrahman Alzahrani / 1/25/2015:

 2. JavaSE[1.8]

 3. Precise command-line compilation examples / instructions:

 e.g.:

 > javac JokeServer.java

 > javac JokeClient.java

 > javac JokeClientAdmin.java

 > java JokeServer

 > java JokeClient

 > java JokeClientAdmin


 4. Precise examples / instructions to run this program:

 e.g.:

 In separate shell windows:

 >   Java JokeServer
 2nd Thread: Abdulrahman's Admin looper is starting up 
 1st Thread: Abdulrahman's Joke server starting up.

 In another shell window 
 >Java JokeClient
 Abdulrahman's Joke Client, 1.8.

 Using server: localhost, Port: 45001
 Please enter your name  rahmo

 Press Enter to get Jokes or Proverbs 
 The valid inputs are : 
 (quit) to close the client. 

 Hey:Rahmo  D.Why doesn't NASA send cows to space?  
 Because the steak would be too high.


 In another shell window  
 >Java JokeClientAdmin
 Abdulrahman Joke Client Admin, 1.8.

 Using server: localhost, Port: 45005
 Enter the mode that you want to switch: 
 The valid inputs are  : 
 a) Joke mode 
 b)Proverb mode 
 c) Maintance mode 
 b
 you chose a Proverb mode


 5. List of files needed for running the program.

 e.g.:


 a. JokeServer.java
 b. JokeClient.java
 c.  JokeClientAdmin.java

 5. Notes:



 ----------------------------------------------------------*/

import java.io.*; // Get the Input Output libraries
import java.net.*; // Get the Java networking libraries
import java.util.Scanner;
import java.util.UUID;

public class JokeClient {
	public static void main(String args[]) {
		String serverName;
		if (args.length < 1)
			serverName = "localhost";
		else
			serverName = args[0];
		System.out.println("Abdulrahman's Joke Client, 1.8.\n");
		System.out.println("Using server: " + serverName + ", Port: 45001");
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		try {
			String UsrName;
			UUID ClientKey = UUID.randomUUID(); // Universally unique identifier
												// intialize in the client to be
												// sent to the server
			System.out.print("Please enter your name  "); // ask the client a
															// name so it can be
															// used for him to
															// be tracked
		
				System.out.flush();
			UsrName = in.readLine(); // get the user name for the client
			String Order;
			
			ClientListener AL = new ClientListener(); // instantiate an object
			Thread t = new Thread(AL); // apply it to another thread
			
			
			do {
				System.out
						.println("\n Press Enter to get Jokes or Proverbs \n The valid inputs are : \n (quit) to close the client. ");
				System.out.flush();
				
				
				Order = in.readLine();// this is each command that is inserted
										// by the client so i can tack if
										// entered Quit
			
	
				if (!t.isAlive()){t.start();}
				
				if (!(Order.indexOf("quit") < 0) == false) {
					SendInfo(UsrName, ClientKey, serverName);// execute this
																// function to
																// process
																// usrname and
																// UUID and the
																// name and the
																// command
				}

			} while (Order.indexOf("quit") < 0);

		} catch (IOException x) {
			x.printStackTrace();
		}
	}

	static void SendInfo(String name, UUID ClientKey, String serverName) {
		Socket sock;
		BufferedReader fromServer;
		PrintStream toServer;
		String textFromServer;
		try {
			sock = new Socket(serverName, 45001); /*
												 * Open connection to server
												 * port, using 1577
												 */
			// Create filter I/O streams for the socket:
			fromServer = new BufferedReader(new InputStreamReader(
					sock.getInputStream()));
			toServer = new PrintStream(sock.getOutputStream());
			// Send machine name or IP address to server:
			toServer.println(name); // so the user get the name and output in
									// his panel that this user is connected
			// toServer.println(name); // Send the joke client name to joke
			// server
			toServer.println(ClientKey);// send the unique identifier to the
										// server so the server track it in a
										// hashmap
			toServer.flush();
			
			
			// Read two or three lines of response from the server,
			// and block while synchronously waiting:
			for (int i = 1; i <= 3; i++) { // number of replies that can be
											// recieved from the server are 3
											// lines
				
			
				textFromServer = fromServer.readLine();// read from server
			
			
				if (textFromServer != null)
					System.out.println(textFromServer);
			}
			sock.close();
		} catch (IOException x) {
			System.out.println("Socket error.");
			x.printStackTrace();
		}
	}

}
	class ClientListener  implements  Runnable  {

		int PORT = 4555;
		  DatagramSocket sk;
		    byte[] buf = new byte[1000];
		  
		    
		
			
		@SuppressWarnings("null")
		@Override
		public void run() {
			// TODO Auto-generated method stub
			 boolean running = true;
			
				while(running) {
			        f();
			        if (Thread.interrupted()) {
			        	Thread.currentThread().interrupt();
			        }
				}
				
				 	
				 
			
		
		   
		
		} 
		
		public void f(){
			try {  
				InetAddress address = InetAddress.getLocalHost();
				DatagramPacket dgp = new DatagramPacket(buf, buf.length,address,4555);
		 			   sk = new DatagramSocket();
				System.out.println("UDP Client connection has started, Please enter number to sum !!");
				 while (true) {   
					
					 BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
			      String outMessage = stdin.readLine(); 
			  
			   
			      buf = (outMessage).getBytes(); 
			      DatagramPacket out = new DatagramPacket(buf, buf.length, dgp.getAddress(), dgp.getPort());
			    
			     
			    
					 sk.send(out);    
//					 BufferedReader stdin2 = new BufferedReader(new InputStreamReader(System.in));
//				      String outMessage2 = stdin2.readLine(); 
//				      buf = (outMessage2).getBytes();
//				      DatagramPacket out2 = new DatagramPacket(buf, buf.length, dgp.getAddress(), dgp.getPort());
//					 sk.send(out2);
//				
					 sk.receive(dgp);
				      String rcvd = new String(dgp.getData(), 0, dgp.getLength()) + ", from address: "
				          + dgp.getAddress() + ", port: " + dgp.getPort();
				      System.out.println(rcvd);
				 
				 }}
			catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   
			
			
			
			
			
		}}
		